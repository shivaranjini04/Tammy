import google.generativeai as genai
import json

genai.configure(api_key="AIzaSyCr2JouJUOqPdXzCMOZ_Tcu21FLN6mlBSI")

model=genai.GenerativeModel("gemini-1.5-flash")

def talk_to_tammy(message):

 prompt=f"""
You are Tammy emotional support assistant.

Max 15 words.

No therapy advice.

Classify severity:

GREEN
YELLOW
RED

Student:

{message}

Return JSON:
response
severity
summary
"""

 r=model.generate_content(prompt)

 text=r.text

 try:

  start=text.find("{")

  end=text.rfind("}")+1

  parsed=json.loads(text[start:end])

 except:

  parsed={

  "response":"I am listening.",

  "severity":"GREEN",

  "summary":"General conversation"

  }

 return parsed


def offline_tammy(text):

 text=text.lower()

 if "hit" in text or "push" in text:

  return{

  "response":"That sounds serious. Counselor will review.",

  "severity":"RED",

  "summary":"Physical harm mentioned"

  }

 elif "alone" in text:

  return{

  "response":"Would you like to share more?",

  "severity":"YELLOW",

  "summary":"Isolation mentioned"

  }

 else:

  return{

  "response":"Thank you for sharing.",

  "severity":"GREEN",

  "summary":"Normal"

  }