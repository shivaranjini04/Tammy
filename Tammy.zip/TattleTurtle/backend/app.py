from flask import Flask,request,jsonify
from flask_cors import CORS
import json
import datetime

from gemini_ai import talk_to_tammy,offline_tammy

app=Flask(__name__)
CORS(app)

DATABASE="database.json"


@app.route("/chat",methods=["POST"])

def chat():

 message=request.json.get("message")

 if not message:

  return jsonify({

  "response":"Please repeat.",

  "severity":"GREEN",

  "summary":"Empty"

  })


 try:

  ai=talk_to_tammy(message)

 except:

  ai=offline_tammy(message)


 log={

 "time":str(datetime.datetime.now()),

 "message":message,

 "severity":ai["severity"],

 "summary":ai["summary"]

 }

 with open(DATABASE,"a") as f:

  f.write(json.dumps(log)+"\n")

 return jsonify(ai)


if __name__=="__main__":

 app.run(debug=True)