async function startListening(){

const status=document.getElementById("status");
const reply=document.getElementById("reply");
const alertBox=document.getElementById("alert");
const mouth=document.getElementById("mouth");

if(!('webkitSpeechRecognition' in window)){
status.innerText="Speech Recognition not supported. Use Chrome.";
return;
}

status.innerText="🎧 Tammy is listening...";

let recognition=new webkitSpeechRecognition();
recognition.lang="en-US";
recognition.start();

recognition.onresult=async function(event){

let speech=event.results[0][0].transcript;

status.innerText="🧒 You said : "+speech;

reply.innerText="🐢 Tammy is thinking...";

let res=await fetch("http://localhost:5000/chat",{

method:"POST",
headers:{"Content-Type":"application/json"},
body:JSON.stringify({message:speech})

});

let data=await res.json();

reply.innerText=data.response;

/* TALKING ANIMATION */
mouth.classList.add("talking");

let speak=new SpeechSynthesisUtterance(data.response);
speechSynthesis.speak(speak);

speak.onend=function(){
mouth.classList.remove("talking");
};

/* ALERT COLORS */

if(data.severity==="RED"){
alertBox.innerHTML="🚨 RED ALERT — Teacher Needed";
alertBox.style.color="red";
}
else if(data.severity==="YELLOW"){
alertBox.innerHTML="⚠️ YELLOW — Pattern Detected";
alertBox.style.color="yellow";
}
else{
alertBox.innerHTML="✅ GREEN — Safe Conversation";
alertBox.style.color="lightgreen";
}

};

}